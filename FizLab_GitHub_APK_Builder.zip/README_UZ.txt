FizLab Android ilovasi — Android Studio loyihasi

Bu loyiha https://fizlab.ultrasoft.uz/ saytini o'z dizaynida Android ilova ichida ochadi.

APK yig'ish:
1. Android Studio o'rnating.
2. Ushbu ZIP faylni oching.
3. Android Studio'da FizLabAndroid papkasini Open qiling.
4. Gradle sync tugashini kuting.
5. Build > Build Bundle(s) / APK(s) > Build APK(s) ni tanlang.
6. APK odatda app/build/outputs/apk/debug/app-debug.apk ichida paydo bo'ladi.

Ilova ID: uz.ultrasoft.fizlab
Minimal Android: 6.0 (API 23)

Eslatma:
- Ilova sayt mazmunini internet orqali yuklaydi; internet kerak.
- Saytdagi yangilanishlar ilovada ham ko'rinadi.
- Ushbu paket Android Studio manba loyihasi; tayyor imzolangan APK emas.
